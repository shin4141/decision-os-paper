# Decision-OS V13: supplementary material

Read V13_Public_PR_Appendix_EN.md for the English inventory and method, or V13_Public_PR_Appendix_07.md for Japanese. Both describe the same fixed 54-PR snapshot.

Keep V13_Public_PR_Data_07.json and recalculate_pr.py in the same directory and run:

```sh
python3 recalculate_pr.py
```

The JSON and script are unchanged from data version 07. The supplement preserves the September 16 observation; it does not report live PR status. This package accompanies the Japanese and English papers. Upload Decision-OS_V13_Supplement.zip alongside the PDFs in the same GitHub folder and Zenodo record.
