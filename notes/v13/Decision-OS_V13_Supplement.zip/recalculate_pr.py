"""Recompute manuscript counts from the accompanying saved public-field snapshot."""
import json
from pathlib import Path
from datetime import datetime, timedelta
from collections import Counter

def dt(s):
    return datetime.fromisoformat(s.replace('Z', '+00:00'))

def calculate(rows):
    boundary = dt('2026-08-15T12:46:30Z')
    baseline = dt('2026-08-15T16:03:00Z')
    before = [r for r in rows if dt(r['opened_at_utc']) < boundary]
    after = [r for r in rows if dt(r['opened_at_utc']) >= boundary]
    def seven(group):
        return sum(r['merged_at_utc'] is not None and timedelta(0) <= dt(r['merged_at_utc'])-dt(r['opened_at_utc']) <= timedelta(days=7) for r in group)
    return {
        'total': len(rows), 'unique_pr_urls': len({r['PR_URL'] for r in rows}),
        'states': dict(Counter(r['state'] for r in rows)),
        'merged_repositories': len({r['repo'] for r in rows if r['state']=='MERGED'}),
        'open_drafts': sum(r['state']=='OPEN' and r['draft'] for r in rows),
        'before': {'n':len(before), 'merged_within_7_days':seven(before), 'percent':round(100*seven(before)/len(before),1)},
        'after': {'n':len(after), 'merged_within_7_days':seven(after), 'percent':round(100*seven(after)/len(after),1)},
        'all_observed_at_least_7_days': all(dt(r['observed_at_utc'])-dt(r['opened_at_utc'])>=timedelta(days=7) for r in rows),
        'baseline_initial_cohort_direct_merges': sum(r['merged_at_utc'] is not None and dt(r['merged_at_utc'])<=baseline for r in before),
        'current_initial_cohort_direct_merges': sum(r['state']=='MERGED' for r in before),
    }

if __name__ == '__main__':
    rows=json.loads(Path(__file__).with_name('V13_Public_PR_Data_07.json').read_text())
    print(json.dumps(calculate(rows),ensure_ascii=False,indent=2))
