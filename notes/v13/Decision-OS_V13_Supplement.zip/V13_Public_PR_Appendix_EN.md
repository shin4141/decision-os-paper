# Appendix A — Public PR Inventory and Recalculation Method

Decision-OS V13 supplement / Data version 07 / September 16, 2026

This inventory covers 54 public PRs created by the shin4141 account in repositories owned by others. Only columns corresponding to public information were extracted from the saved CSV. Internal learning IDs, case IDs, source indexes, and evaluation notes are excluded. Not every event was independently retrieved from GitHub for this release. Current status at the linked pages may change.

All rows use the fixed observation time 2026-09-16T04:02:21Z. Dates are UTC. A dash means that the saved data contain no timestamp for that field. State is normalized to MERGED, CLOSED, or OPEN; draft is retained as observed. CLOSED does not mean technical rejection, and adoption through another route cannot be determined from this column alone. Self-owned repositories, private or deleted PRs, other identities, submissions outside GitHub, and candidates stopped before submission are excluded.

## Recalculation

Keep `V13_Public_PR_Data_07.json` and `recalculate_pr.py` together. Run `python3 recalculate_pr.py` with Python 3. No additional libraries or network connection are required.

The rule-fix boundary is 2026-08-15T12:46:30Z. The comparison separates 28 PRs created before that boundary from 26 created at or after it, counting direct merges within seven days of creation. Every PR had at least seven days of observation. Case composition and other factors are not controlled; this comparison does not estimate a causal effect.

The initial cohort baseline is August 16, 2026, 01:03 JST (2026-08-15T16:03:00Z). The timestamp is supported by the unpublished record cited as reference [18] in the paper. The count of eight can itself be recalculated from saved public-event timestamps.

| Measure | Result |
|---|---:|
| Total PRs | 54 |
| Directly merged / closed / open | 32 / 8 / 14 |
| Repositories receiving direct merges | 28 |
| Open drafts | 1 |
| Merged within seven days, before rule fix | 18/28 = 64.3% |
| Merged within seven days, after rule fix | 11/26 = 42.3% |
| Initial cohort direct merges: baseline to observation | 8 to 19 |

The later OpenSSL upstream integration described in Section 4.3 is subsequent to this fixed observation. The saved row and aggregate counts are therefore unchanged.

## PR inventory

The observation time above applies to every row and is also retained in each JSON record.

| PR | Created UTC | Merged UTC | Closed UTC | State | draft |
|---|---|---|---|---|---|
| [pooza/makoto2 #56](https://github.com/pooza/makoto2/pull/56) | 2026-08-14T01:51:28Z | 2026-08-14T21:34:12Z | 2026-08-14T21:34:12Z | MERGED | false |
| [rictaworks/questboard #151](https://github.com/rictaworks/questboard/pull/151) | 2026-08-14T02:11:43Z | 2026-08-14T05:48:35Z | 2026-08-14T05:48:35Z | MERGED | false |
| [ritsth/job-autofill-extension #215](https://github.com/ritsth/job-autofill-extension/pull/215) | 2026-08-14T03:34:48Z | 2026-08-14T18:43:35Z | 2026-08-14T18:43:35Z | MERGED | false |
| [Johnkothapalli/python-code-health-analyzer #19](https://github.com/Johnkothapalli/python-code-health-analyzer/pull/19) | 2026-08-14T03:39:29Z | 2026-08-20T14:47:38Z | 2026-08-20T14:47:38Z | MERGED | false |
| [mldsveda/PyScrappy #148](https://github.com/mldsveda/PyScrappy/pull/148) | 2026-08-14T03:43:50Z | 2026-08-14T06:46:27Z | 2026-08-14T06:46:27Z | MERGED | false |
| [LobsterTrap/lola #236](https://github.com/LobsterTrap/lola/pull/236) | 2026-08-14T04:46:13Z | — | — | OPEN | false |
| [griddynamics/rosetta #284](https://github.com/griddynamics/rosetta/pull/284) | 2026-08-14T05:07:21Z | 2026-08-19T17:54:23Z | 2026-08-19T17:54:23Z | MERGED | false |
| [papra-hq/papra #1426](https://github.com/papra-hq/papra/pull/1426) | 2026-08-14T05:20:03Z | — | 2026-08-17T23:52:42Z | CLOSED | false |
| [griddynamics/rosetta #285](https://github.com/griddynamics/rosetta/pull/285) | 2026-08-14T06:47:03Z | 2026-08-19T18:05:33Z | 2026-08-19T18:05:33Z | MERGED | false |
| [gren-lang/core #135](https://github.com/gren-lang/core/pull/135) | 2026-08-14T07:13:46Z | 2026-08-14T07:37:26Z | 2026-08-14T07:37:26Z | MERGED | false |
| [bmad-code-org/bmad-loop #587](https://github.com/bmad-code-org/bmad-loop/pull/587) | 2026-08-14T07:31:17Z | 2026-08-18T02:55:52Z | 2026-08-18T02:55:52Z | MERGED | false |
| [dynawo/dyn-grid-compliance-verification #385](https://github.com/dynawo/dyn-grid-compliance-verification/pull/385) | 2026-08-14T07:55:41Z | 2026-08-24T08:49:27Z | 2026-08-24T08:49:27Z | MERGED | false |
| [DataDave-Dev/weftmap #175](https://github.com/DataDave-Dev/weftmap/pull/175) | 2026-08-14T08:30:12Z | 2026-08-14T15:29:03Z | 2026-08-14T15:29:03Z | MERGED | false |
| [orion-agents/orion-code #201](https://github.com/orion-agents/orion-code/pull/201) | 2026-08-14T08:55:58Z | — | 2026-08-14T17:08:37Z | CLOSED | false |
| [getCodesema/codesema-cli #32](https://github.com/getCodesema/codesema-cli/pull/32) | 2026-08-14T16:40:26Z | 2026-08-18T15:15:59Z | 2026-08-18T15:15:59Z | MERGED | false |
| [KaotoIO/camel-catalog #130](https://github.com/KaotoIO/camel-catalog/pull/130) | 2026-08-14T16:51:30Z | 2026-08-20T07:46:42Z | 2026-08-20T07:46:42Z | MERGED | false |
| [nativewind/react-native-css #419](https://github.com/nativewind/react-native-css/pull/419) | 2026-08-14T22:20:09Z | — | — | OPEN | false |
| [temporalio/deputy #314](https://github.com/temporalio/deputy/pull/314) | 2026-08-14T23:13:33Z | — | — | OPEN | false |
| [GuyTeichman/RNAlysis #289](https://github.com/GuyTeichman/RNAlysis/pull/289) | 2026-08-14T23:16:44Z | 2026-08-15T08:15:48Z | 2026-08-15T08:15:48Z | MERGED | false |
| [aws-samples/sample-voice-of-customer-datalake #330](https://github.com/aws-samples/sample-voice-of-customer-datalake/pull/330) | 2026-08-14T23:45:46Z | — | — | OPEN | false |
| [wingfoil-io/wingfoil #839](https://github.com/wingfoil-io/wingfoil/pull/839) | 2026-08-14T23:55:26Z | 2026-08-15T00:35:08Z | 2026-08-15T00:35:08Z | MERGED | false |
| [TwiN/gatus #1759](https://github.com/TwiN/gatus/pull/1759) | 2026-08-15T01:21:24Z | — | — | OPEN | false |
| [keycloak/keycloak #51749](https://github.com/keycloak/keycloak/pull/51749) | 2026-08-15T01:51:31Z | — | — | OPEN | false |
| [vercel/workflow #3575](https://github.com/vercel/workflow/pull/3575) | 2026-08-15T03:43:17Z | 2026-08-22T02:18:45Z | 2026-08-22T02:18:45Z | MERGED | false |
| [cerbos/cerbos #3328](https://github.com/cerbos/cerbos/pull/3328) | 2026-08-15T04:23:02Z | — | 2026-08-20T07:55:36Z | CLOSED | false |
| [mercurjs/mercur #1399](https://github.com/mercurjs/mercur/pull/1399) | 2026-08-15T05:50:35Z | 2026-08-21T13:48:52Z | 2026-08-21T13:48:52Z | MERGED | false |
| [rdkit/rdkit #9512](https://github.com/rdkit/rdkit/pull/9512) | 2026-08-15T10:43:11Z | 2026-08-21T02:51:46Z | 2026-08-21T02:51:46Z | MERGED | false |
| [ritsth/job-autofill-extension #221](https://github.com/ritsth/job-autofill-extension/pull/221) | 2026-08-15T12:45:20Z | 2026-08-16T20:51:13Z | 2026-08-16T20:51:13Z | MERGED | false |
| [DataDave-Dev/weftmap #178](https://github.com/DataDave-Dev/weftmap/pull/178) | 2026-08-16T08:03:45Z | 2026-08-18T14:43:15Z | 2026-08-18T14:43:15Z | MERGED | false |
| [pooza/makoto2 #94](https://github.com/pooza/makoto2/pull/94) | 2026-08-17T09:48:16Z | 2026-08-17T22:33:34Z | 2026-08-17T22:33:34Z | MERGED | false |
| [openclaw/openclaw #125722](https://github.com/openclaw/openclaw/pull/125722) | 2026-08-18T08:23:38Z | — | 2026-08-26T06:28:29Z | CLOSED | false |
| [openclaw/openclaw #125736](https://github.com/openclaw/openclaw/pull/125736) | 2026-08-18T08:41:40Z | — | 2026-08-22T18:44:21Z | CLOSED | true |
| [apple/swift-openapi-generator #939](https://github.com/apple/swift-openapi-generator/pull/939) | 2026-08-19T02:51:50Z | 2026-08-20T16:34:36Z | 2026-08-20T16:34:37Z | MERGED | false |
| [sony/nmos-cpp #520](https://github.com/sony/nmos-cpp/pull/520) | 2026-08-19T04:59:07Z | 2026-08-21T13:27:37Z | 2026-08-21T13:27:37Z | MERGED | false |
| [NII-cloud-operation/nbsearch #76](https://github.com/NII-cloud-operation/nbsearch/pull/76) | 2026-08-20T01:22:49Z | — | — | OPEN | false |
| [OSC/ondemand #5725](https://github.com/OSC/ondemand/pull/5725) | 2026-08-22T17:16:26Z | 2026-08-27T15:08:42Z | 2026-08-27T15:08:42Z | MERGED | false |
| [root-project/cling #568](https://github.com/root-project/cling/pull/568) | 2026-08-23T00:00:33Z | — | — | OPEN | false |
| [esa/pagmo2 #634](https://github.com/esa/pagmo2/pull/634) | 2026-08-23T01:34:31Z | — | — | OPEN | false |
| [nasa-jpl/explorer-1 #892](https://github.com/nasa-jpl/explorer-1/pull/892) | 2026-08-23T03:24:44Z | — | — | OPEN | false |
| [usnistgov/fipy #1224](https://github.com/usnistgov/fipy/pull/1224) | 2026-08-23T05:34:23Z | — | 2026-08-26T19:19:18Z | CLOSED | false |
| [besu-eth/besu #11128](https://github.com/besu-eth/besu/pull/11128) | 2026-08-23T11:52:26Z | 2026-08-27T06:28:02Z | 2026-08-27T06:28:02Z | MERGED | false |
| [FHIR/sushi #1635](https://github.com/FHIR/sushi/pull/1635) | 2026-08-23T12:19:09Z | 2026-09-03T12:25:37Z | 2026-09-03T12:25:38Z | MERGED | false |
| [anza-xyz/kit #1971](https://github.com/anza-xyz/kit/pull/1971) | 2026-08-23T13:14:40Z | 2026-08-27T16:43:25Z | 2026-08-27T16:43:25Z | MERGED | false |
| [Adyen/adyen-node-api-library #1760](https://github.com/Adyen/adyen-node-api-library/pull/1760) | 2026-08-24T04:04:49Z | 2026-08-24T09:28:52Z | 2026-08-24T09:28:52Z | MERGED | false |
| [WorksApplications/sudachi.rs #360](https://github.com/WorksApplications/sudachi.rs/pull/360) | 2026-08-24T04:26:49Z | 2026-08-28T08:43:24Z | 2026-08-28T08:43:24Z | MERGED | false |
| [PowerGridModel/power-grid-model #1547](https://github.com/PowerGridModel/power-grid-model/pull/1547) | 2026-08-24T12:28:33Z | 2026-09-15T14:08:26Z | 2026-09-15T14:08:26Z | MERGED | false |
| [rundeck/rundeck #10488](https://github.com/rundeck/rundeck/pull/10488) | 2026-08-24T15:34:08Z | — | — | OPEN | false |
| [agno-agi/agno #9766](https://github.com/agno-agi/agno/pull/9766) | 2026-08-24T21:21:02Z | — | 2026-08-24T21:21:16Z | CLOSED | false |
| [metabase/metabase #80783](https://github.com/metabase/metabase/pull/80783) | 2026-08-25T00:31:03Z | — | — | OPEN | false |
| [aws/aws-sdk-js-v3 #8278](https://github.com/aws/aws-sdk-js-v3/pull/8278) | 2026-08-25T15:19:03Z | — | 2026-09-03T18:21:41Z | CLOSED | false |
| [microsoft/terraform-provider-power-platform #1254](https://github.com/microsoft/terraform-provider-power-platform/pull/1254) | 2026-08-25T18:00:11Z | 2026-08-28T07:09:16Z | 2026-08-28T07:09:16Z | MERGED | false |
| [usnistgov/macos_security #775](https://github.com/usnistgov/macos_security/pull/775) | 2026-08-26T03:23:48Z | 2026-08-26T18:07:48Z | 2026-08-26T18:07:48Z | MERGED | false |
| [UniversalRobots/Universal_Robots_ROS2_Driver #1951](https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/pull/1951) | 2026-09-02T02:15:47Z | — | — | OPEN | true |
| [openssl/openssl #32685](https://github.com/openssl/openssl/pull/32685) | 2026-09-04T16:14:55Z | — | — | OPEN | false |
